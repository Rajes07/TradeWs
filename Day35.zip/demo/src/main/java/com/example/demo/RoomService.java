package com.example.demo;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.mode.Room;

@Service
@Transactional
public class RoomService {

	
	
	@Autowired
	private RoomRepo repo;
	
	
	public Room createRoom(Room room) {
		return repo.save(room);
		}
}
