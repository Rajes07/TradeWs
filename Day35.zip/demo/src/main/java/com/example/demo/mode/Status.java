package com.example.demo.mode;

public enum Status {
          
	
	
	AVAILABLE,BOOKED	
}
