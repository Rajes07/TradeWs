package Infinite.OyoClient;

public class Room {
     
	private String roomid;
	private String type;
	private Status status;
	private int costperday;
	public String getRoomid() {
		return roomid;
	}
	public void setRoomid(String roomid) {
		this.roomid = roomid;
	}
	public String getType() {
		return type;
	}
	public void setType(String type) {
		this.type = type;
	}
	public Status getStatus() {
		return status;
	}
	public void setStatus(Status status) {
		this.status = status;
	}
	public int getCostperday() {
		return costperday;
	}
	public void setCostperday(int costperday) {
		this.costperday = costperday;
	}
	@Override
	public String toString() {
		return "Room [roomid=" + roomid + ", type=" + type + ", status=" + status + ", costperday=" + costperday + "]";
	}





}

