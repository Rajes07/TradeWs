package Infinite.OyoClient;

public enum Status {
   AVAILABLE,BOOKED
}
