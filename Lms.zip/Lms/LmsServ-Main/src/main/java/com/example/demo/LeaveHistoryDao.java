package com.example.demo;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.PreparedStatementSetter;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.jdbc.core.RowMapperResultSetExtractor;
import org.springframework.stereotype.Repository;

@Repository
public class LeaveHistoryDao {
	
	@Autowired
	private JdbcTemplate jdbc;
	
	public LeaveHistory[] pendingLeaves(){
		
		String cmd="Select * from leave_history where LEAVE_STATUS='PENDING'";
	
	    List <LeaveHistory> Str=jdbc.query(cmd,new Object[] {},new RowMapper<LeaveHistory>() {

			@Override
			public LeaveHistory mapRow(ResultSet rs, int rowNum) throws SQLException {
			
				LeaveHistory l= new LeaveHistory();
				l.setLeaveId(rs.getInt("LEAVE_ID"));
				l.setLeaveNoOfDays(rs.getInt("LEAVE_NO_OF_DAYS"));
				l.setLeaveMngrComments(rs.getString("LEAVE_MNGR_COMMENTS"));
				l.setEmpId(rs.getInt("EMP_ID"));
				l.setLeaveStartDate(rs.getDate("LEAVE_START_DATE"));
				l.setLeaveEndDate(rs.getDate("LEAVE_END_DATE"));
				l.setLeaveType(rs.getString("LEAVE_TYPE"));
				l.setLeaveStatus(rs.getString("LEAVE_STATUS"));
				l.setLeaveReason(rs.getString("LEAVE_REASON"));
				return l;
			}
			});
		
				
				return Str.toArray(new LeaveHistory[Str.size()]);
		
	}
	
	
	public String ApplyLeave(LeaveHistory leave) {
		String cmd="Insert into LEAVE_HISTORY(Emp_ID,Leave_Start_Date, "
				+ "Leave_End_Date,Leave_Type,Leave_Status,Leave_Reason,LEAVE_NO_OF_DAYS) "
				+ "VALUES(?,?,?,?,?,?,?)";
		jdbc.update(cmd,new PreparedStatementSetter() {
			
			@Override
			public void setValues(PreparedStatement ps) throws SQLException {
				ps.setInt(1,leave.getEmpId());
				ps.setDate(2, leave.getLeaveStartDate());
				ps.setDate(3,leave.getLeaveEndDate());
				ps.setString(4, leave.getLeaveType());
				ps.setString(5,leave.getLeaveStatus());
				ps.setString(6, leave.getLeaveReason());
				ps.setInt(7,leave.getLeaveNoOfDays());
				
				ps.execute(cmd);
			}
		});
		return cmd;
		
	}

}
