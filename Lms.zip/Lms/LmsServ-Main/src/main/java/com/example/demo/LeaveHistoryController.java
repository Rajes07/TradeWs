package com.example.demo;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class LeaveHistoryController {

	@Autowired
	public LeaveHistoryService serv;
	
	@Autowired
	public LeaveHistoryDao dao;
	
	
	@PostMapping(value="/add")
	public String add(@RequestBody LeaveHistory leave) {
		return serv.addLeave(leave);
	}
	
	
	@RequestMapping(value="/pending")
	public LeaveHistory[] pendog() {
		return serv.pending();
	}
	
	@RequestMapping(value="/searchleave/{leaveId}")
	public LeaveHistory search(@PathVariable int leaveId){
		return serv.search(leaveId);
	}
	@RequestMapping(value="/showLeave")
	public List<LeaveHistory> showAll(){
		return serv.findall();
	}
}
