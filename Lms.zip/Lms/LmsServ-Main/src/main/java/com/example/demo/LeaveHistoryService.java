package com.example.demo;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
@Transactional
public class LeaveHistoryService {

	
	@Autowired
	private LeavehistoryRepo repo;
	
	@Autowired
	private LeaveHistoryDao dao;
	
	public String addLeave(LeaveHistory leave) {
		return dao.ApplyLeave(leave);
	}
	
	public LeaveHistory[] pending() {
		return dao.pendingLeaves();
	}
	
	public LeaveHistory search(int leaveId) {
		return repo.findById(leaveId).get();
	}
	
	public List<LeaveHistory> findall(){
		return repo.findAll();
	}
}
