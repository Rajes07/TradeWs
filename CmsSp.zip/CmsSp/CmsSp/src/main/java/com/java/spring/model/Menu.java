package com.java.spring.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import com.java.spring.enume.MenuStatus;

@Entity
@Table(name="Menu")
public class Menu {

	@Id
	private int menuId;
	public int getMenuId() {
		return menuId;
	}
	public void setMenuId(int menuId) {
		this.menuId = menuId;
	}
	public String getMenuItem() {
		return menuItem;
	}
	public void setMenuItem(String menuItem) {
		this.menuItem = menuItem;
	}
	public double getMenuPrice() {
		return menuPrice;
	}
	public void setMenuPrice(double menuPrice) {
		this.menuPrice = menuPrice;
	}
	public double getMenuCalories() {
		return menuCalories;
	}
	public void setMenuCalories(double menuCalories) {
		this.menuCalories = menuCalories;
	}
	private String menuItem;
	private double menuPrice;
	private double menuCalories;
	private String menuStatus;
	public String getMenuStatus() {
		return menuStatus;
	}
	public void setMenuStatus(String menuStatus) {
		this.menuStatus = menuStatus;
	}
	
	private String menuRating;
	public String getMenuRating() {
		return menuRating;
	}
	public void setMenuRating(String menuRating) {
		this.menuRating = menuRating;
	}
	public String getMenuType() {
		return menuType;
	}
	public void setMenuType(String menuType) {
		this.menuType = menuType;
	}
	private String menuType;
}

