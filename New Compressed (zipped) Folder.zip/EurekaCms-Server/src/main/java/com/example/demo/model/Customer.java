package com.example.demo.model;

import javax.persistence.Entity;
import javax.persistence.Id;

@Entity
public class Customer {


	@Id
	private int cusId;
	private String cusName;
	private String cusPhnno;
	private String cusPassword;
	public String getCusPassword() {
		return cusPassword;
	}
	public void setCusPassword(String cusPassword) {
		this.cusPassword = cusPassword;
	}
	public String getCusEmail() {
		return cusEmail;
	}
	public void setCusEmail(String cusEmail) {
		this.cusEmail = cusEmail;
	}
	public String getCusDob() {
		return cusDob;
	}
	public void setCusDob(String cusDob) {
		this.cusDob = cusDob;
	}
	public String getCusAddress() {
		return cusAddress;
	}
	public void setCusAddress(String cusAddress) {
		this.cusAddress = cusAddress;
	}
	private String cusEmail;
	private String cusDob;
	private String cusAddress;
	
	public String getCusPhnno() {
		return cusPhnno;
	}
	public void setCusPhnno(String cusPhnno) {
		this.cusPhnno = cusPhnno;
	}
	private String cusUsername;
	public int getCusId() {
		return cusId;
	}
	public void setCusId(int cusId) {
		this.cusId = cusId;
	}
	public String getCusName() {
		return cusName;
	}
	public void setCusName(String cusName) {
		this.cusName = cusName;
	}
	
	public String getCusUsername() {
		return cusUsername;
	}
	public void setCusUsername(String cusUsername) {
		this.cusUsername = cusUsername;
	}
	public Customer(int cusId, String cusName, String cusPhnno, String cusUsername) {
		super();
		this.cusId = cusId;
		this.cusName = cusName;
		this.cusPhnno = cusPhnno;
		this.cusUsername = cusUsername;
	}

	
	public Customer() {
		// TODO Auto-generated constructor stub
	}


}
