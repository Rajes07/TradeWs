package com.example.demo.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.example.demo.CustomRepo.CustomerDao;
import com.example.demo.model.Customer;
import com.example.demo.repo.CustomerRepo;


@Transactional
@Service
public class CustomerService {

	@Autowired
	private CustomerRepo repo;

	@Autowired
   private CustomerDao dao;

	public String authenticate(String user,String pwd) {
		return dao.authenticate(user, pwd);
	}
	
	public Customer search(int menuId) {
		return repo.findById(menuId).get();
	}
	public List<Customer> showEmploy() {
		return repo.findAll();
	}
}
