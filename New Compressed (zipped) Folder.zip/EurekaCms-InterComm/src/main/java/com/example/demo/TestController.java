package com.example.demo;

import java.util.NoSuchElementException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;

@RestController
public class TestController {
	@Autowired
	private RestTemplate restTemplate;
	
	@GetMapping("/menu")
	public Object[] getMenu() {
		Object[] menu = restTemplate.getForObject("http://eureka-cms-server/showMenu", Object[].class);
		return menu;
		
	}
		
	@GetMapping("/cus")
	public Object[] getCus() {
		Object[] cus = restTemplate.getForObject("http://eureka-cms-server/showCustomer", Object[].class);
		return cus;
		
	}
	@GetMapping("/menusearch/{id}")
	public Object getMenuById(@PathVariable int id) {
		Object menu = restTemplate.getForObject("http://eureka-cms-server/menu/"+id, Object.class);
		return menu;
		
	}
	@GetMapping("/cus/{id}")
	public Object getcusById(@PathVariable int id) {
		Object cus = restTemplate.getForObject("http://eureka-cms-server/customer/"+id, Object.class);
		return cus;
		
	}
	@GetMapping("/vendor")
	public Object[] getVen() {
		Object[] ven = restTemplate.getForObject("http://eureka-cms-server/showVendor", Object[].class);
		return ven;
		
	}
	
	@GetMapping("/ven/{id}")
	public Object getvenById(@PathVariable int id) {
		Object ven = restTemplate.getForObject("http://eureka-cms-server/vendor/"+id, Object.class);
		return ven;
		
	}
	
	@GetMapping("/wal/{id}")
	public Object getwalById(@PathVariable int id) {
		Object wal = restTemplate.getForObject("http://eureka-cms-server/wallet/"+id, Object.class);
		return wal;
		
	}

	
	
	@GetMapping("/cuswallet/{id}")
	public Object getCuswalById(@PathVariable int id) {
		Object wal = restTemplate.getForObject("http://eureka-cms-server/showCustomerWallet/"+id, Object.class);
		return wal;
		
	}
	
	

	
	@GetMapping("/venord/{id}")
	public Object getVenOrdById(@PathVariable int id) {
		Object ven = restTemplate.getForObject("http://eureka-cms-server/vendorOrders/"+id, Object.class);
		return ven;
		
	}
	
	@GetMapping("/venpenord/{id}")
	public Object getVenPenOrdById(@PathVariable int id) {
		Object ven = restTemplate.getForObject("http://eureka-cms-server/vendorPendingOrders/"+id, Object.class);
		return ven;
		
	}
	
	@GetMapping("/cusord/{id}")
	public Object CusOrdById(@PathVariable int id) {
		Object cus = restTemplate.getForObject("http://eureka-cms-server/customerOrders/"+id, Object.class);
		return cus;
		
	}
  
	@GetMapping("/cuspenord/{id}")
	public Object CusPenOrdById(@PathVariable int id) {
		Object cus = restTemplate.getForObject("http://eureka-cms-server/customerPendingOrders/"+id, Object.class);
		return cus;
		
	}
}
